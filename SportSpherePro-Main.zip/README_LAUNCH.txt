
SPORTSPHEREPRO — MAIN (Drag & Drop to Netlify)
1) Upload ZIP.
2) Add environment variables from .env into Netlify → Site → Settings → Env vars.
3) Publish dir: public. Functions: netlify/functions.
4) Visit /admin.html to submit human picks (needs ANALYST_TOKEN).
5) Live updates every 60s; Slack alerts use WEBHOOK_URL.
