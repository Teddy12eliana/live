exports.handler=async()=>({statusCode:200,body:JSON.stringify({items:[
{name:"Stephen A. Smith",network:"ESPN",program:"NBA Countdown",ts:"Oct 8, 2025 6:05 PM ET",league:"NBA",match:"Lakers vs Warriors",quote:"LeBron’s urgency in elimination games is different."},
{name:"Skip Bayless",network:"FOX Sports",program:"UNDISPUTED",ts:"Oct 8, 2025 5:40 PM ET",league:"NFL",match:"49ers vs Chiefs",quote:"Chiefs bounce back if O-line holds up."},
{name:"BBC Panel",network:"BBC",program:"Match of the Day",ts:"Oct 8, 2025 1:15 PM ET",league:"EPL",match:"Arsenal vs Spurs",quote:"Arsenal’s home form should carry them."}
]})});