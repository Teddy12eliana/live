exports.handler=async()=>({statusCode:200,body:JSON.stringify({items:[
{title:"LeBron cleared to play after rest",source:"ESPN",url:"https://www.espn.com",time:"Today"},
{title:"Arsenal extend unbeaten home run",source:"BBC Sport",url:"https://www.bbc.com/sport",time:"Today"}
]})});