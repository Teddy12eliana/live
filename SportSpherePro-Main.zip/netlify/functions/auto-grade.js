exports.handler=async()=>({statusCode:200,body:JSON.stringify({ai:[
{league:"EPL",match:"Arsenal vs Chelsea",pick:"Arsenal ML",confidence:68,rationale:"xG trend L5; right-side xThreat."},
{league:"NBA",match:"Lakers vs Warriors",pick:"Over 229.5",confidence:61,rationale:"Top-10 pace; bench D -8."},
{league:"NFL",match:"49ers vs Chiefs",pick:"49ers -2.5",confidence:64,rationale:"Pass rush win rate; OL injuries."}
],updated:new Date().toISOString()})});