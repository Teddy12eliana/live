// netlify/functions/odds-fetcher.js
import fetch from "node-fetch";

export async function handler() {
  try {
    const key = process.env.ODDS_API_KEY;
    const response = await fetch(`https://api.the-odds-api.com/v4/sports/?apiKey=${key}`);
    const data = await response.json();

    return {
      statusCode: 200,
      body: JSON.stringify({ sports: data }),
    };
  } catch (err) {
    return { statusCode: 500, body: err.message };
  }
}
