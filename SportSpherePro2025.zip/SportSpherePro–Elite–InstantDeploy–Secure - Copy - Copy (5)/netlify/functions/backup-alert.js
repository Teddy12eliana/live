// netlify/functions/backup-alert.js
import fetch from "node-fetch";

export async function handler() {
  const webhook = process.env.WEBHOOK_URL;
  const message = `🛡️ Backup alert triggered at ${new Date().toLocaleString()}`;
  
  if (webhook) {
    await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: message }),
    });
  }

  return {
    statusCode: 200,
    body: JSON.stringify({ status: "backup alert sent" }),
  };
}
