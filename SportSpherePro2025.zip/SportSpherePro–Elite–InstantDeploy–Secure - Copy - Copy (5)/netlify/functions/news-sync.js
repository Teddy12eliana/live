// netlify/functions/news-sync.js
import fetch from "node-fetch";

export async function handler() {
  try {
    const newsSources = [
      "https://site.api.espn.com/apis/site/v2/sports/news",
      "https://www.thesportsdb.com/api/v1/json/2/news.php?s=Soccer"
    ];

    const results = await Promise.all(newsSources.map(src => fetch(src).then(r => r.json())));
    return {
      statusCode: 200,
      body: JSON.stringify({ latest: results }),
    };
  } catch (err) {
    return { statusCode: 500, body: `Error fetching news: ${err.message}` };
  }
}
