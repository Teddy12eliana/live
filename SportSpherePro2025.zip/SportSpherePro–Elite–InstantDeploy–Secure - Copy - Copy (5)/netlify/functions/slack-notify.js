// netlify/functions/slack-notify.js
import fetch from "node-fetch";

/**
 * Slack Notifier
 * Sends automatic updates to your Slack channel
 */

export async function handler(event) {
  try {
    const webhookUrl = process.env.WEBHOOK_URL;

    const payload = {
      text: "🔥 *SportsSpherePro Update!* New AI and Hybrid predictions are live!\nVisit: https://sportsspherepro.com",
    };

    const res = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      throw new Error(`Slack webhook failed: ${res.statusText}`);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, message: "Slack notified" }),
    };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
}
