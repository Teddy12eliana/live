// netlify/functions/email-welcome.js
import fetch from "node-fetch";

/**
 * Sends a welcome email to new users via SendGrid.
 */
export async function handler(event) {
  try {
    const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
    const FROM_EMAIL = "admin@sportsspherepro.com";
    const { email, name } = JSON.parse(event.body || "{}");

    if (!email) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Email is required." }),
      };
    }

    const message = {
      personalizations: [
        {
          to: [{ email }],
          subject: `Welcome to SportsSpherePro, ${name || "Champion"}!`,
        },
      ],
      from: { email: FROM_EMAIL, name: "SportsSpherePro Team" },
      content: [
        {
          type: "text/html",
          value: `
            <div style="font-family: Arial, sans-serif; padding: 20px;">
              <h2>🏆 Welcome to <span style="color:#D4AF37;">SportsSpherePro</span>!</h2>
              <p>Hey ${name || "there"},</p>
              <p>You're officially part of the <strong>AI + Human Sports Revolution</strong>.</p>
              <p>Track predictions, check live odds, and stay ahead before the big games!</p>
              <p><a href="https://sportsspherepro.com" 
              style="background:#D4AF37;color:#000;padding:10px 20px;text-decoration:none;border-radius:5px;font-weight:bold;">Go to Dashboard</a></p>
              <hr/>
              <p style="font-size:12px;color:#999;">© 2025 SportsSpherePro — All Rights Reserved</p>
            </div>
          `,
        },
      ],
    };

    const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${SENDGRID_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(message),
    });

    if (!res.ok) throw new Error(`SendGrid failed: ${res.statusText}`);

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, message: "Email sent!" }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message }),
    };
  }
}
