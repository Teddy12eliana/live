# 🏆 SportSpherePro 2025 — Elite Instant Deploy Edition

Your all-in-one **AI + Human Sports Prediction Engine** with live odds, news sync, secure checkout, and admin dashboard.

---

## 🚀 Deployment Guide

### 1️⃣ Requirements
- **Netlify account** (free)
- **GitHub repository**
- **API keys:**
  - [The Odds API](https://the-odds-api.com)
  - [TheSportsDB](https://www.thesportsdb.com)
  - [Stripe](https://dashboard.stripe.com)
  - [SendGrid](https://sendgrid.com)
  - Slack webhook *(optional for alerts)*

---

### 2️⃣ Environment Variables
In **Netlify → Site Settings → Environment Variables**, add:

| Key | Example Value |
|------|---------------|
| ODDS_API_KEY | `c1a8ca5227b1e00995d544b8ab17b126` |
| THESPORTSDB_KEY | `286254` |
| WEBHOOK_URL | `https://hooks.slack.com/services/...` |
| STRIPE_SECRET_KEY | `sk_live_...` |
| SENDGRID_API_KEY | `SG.xxxxx` |
| ADMIN_PASS | `SphereMaster2025` |
| ADMIN_MASTER_KEY | `Q9tZ8WfV7yM2sH0pN3eL6kG4xR1cJ5bT` |
| JOBS_ENABLED | `true` |

---

### 3️⃣ Netlify Build Settings

| Setting | Value |
|----------|--------|
| **Build command** | `npm install && npm run build || echo 'No build step'` |
| **Publish directory** | `public` |
| **Functions directory** | `netlify/functions` |

Then click **Deploy Site** 🚀

---

## 🧠 Key Features

✅ **AI Predictor** → Automated picks from live odds  
✅ **Hybrid Predictor** → Combines AI + human analyst insights  
✅ **News Sync** → Pulls breaking sports news from ESPN & TheSportsDB  
✅ **Slack Alerts** → Sends updates to your Slack channel  
✅ **Stripe Checkout** → Handles payments for premium access  
✅ **Welcome Email** → Sends confirmation via SendGrid  
✅ **Backup Alerts** → Auto Slack pings for system health  

---

## 🧩 Admin Access

- **Login:** `/admin/admin.html`  
- **Password:** `SphereMaster2025`  
- **Dashboard:** `/admin/dashboard.js`

---

## 💾 Headers & Security

All requests are secured via `_headers`:


---

## 🧩 Serverless Functions Included

| Function | Description |
|-----------|--------------|
| ai-predictor.js | Core AI sports prediction engine |
| hybrid-predictor.js | AI + Human expert prediction hybrid |
| odds-fetcher.js | Pulls live sports + odds data |
| news-sync.js | Sports news aggregator |
| stripe-checkout.js | Payment and subscription handler |
| slack-notify.js | Sends live updates to Slack |
| email-welcome.js | Sends SendGrid welcome emails |
| backup-alert.js | Sends automatic backup alerts |

---

## 🌐 Live Deployment

When deployed, your site will appear at:  
👉 **https://sportsspherepro.com**  
Or your Netlify custom subdomain.

---

## ✉️ Credits

Built by **Teddy** with support from **ChatGPT-5**  
Powered by **The Odds API**, **TheSportsDB**, **Stripe**, **SendGrid**, and **Netlify**.

---

### 💡 Pro Tip

Every change you push to GitHub automatically redeploys your live site on Netlify.  
To test functions locally, run:

```bash
netlify dev


---

✅ **Next Step:**  
1. Paste that whole thing into your root `README.md`.  
2. Save it.  
3. You’re done — that’s your official documentation.  

Would you like me to generate the clean ZIP (SportSpherePro2025–FinalDeploy.zip) right after this so you can drag & drop it into Netlify?
