import { getStore } from '@netlify/blobs'
export async function handler(){ const s=getStore('accuracy-store'); const txt=await s.get('accuracy.json',{type:'text'}); return { statusCode:200, headers:{'content-type':'application/json'}, body: txt || '[]' } }
