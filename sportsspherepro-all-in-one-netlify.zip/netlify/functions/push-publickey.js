export async function handler(){
  // Expose VAPID public key to the client for subscription
  const publicKey = process.env.VAPID_PUBLIC_KEY || null
  if (!publicKey) return { statusCode:400, body: JSON.stringify({ error:'missing VAPID_PUBLIC_KEY' }) }
  return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ publicKey }) }
}
