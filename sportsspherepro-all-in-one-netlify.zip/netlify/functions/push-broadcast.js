import { getStore } from '@netlify/blobs'
export async function handler(event){
  if (event.httpMethod!=='POST') return { statusCode:405, body:'Method Not Allowed' }
  const { default: webpush } = await import('web-push')
  const s = getStore('accuracy-store')
  const txt = await s.get('push-subs.json', { type:'text' })
  const subs = txt? JSON.parse(txt): []
  const { title, body, url } = JSON.parse(event.body || '{}')
  if (!process.env.VAPID_PUBLIC_KEY || !process.env.VAPID_PRIVATE_KEY) return { statusCode:400, body:'Missing VAPID keys' }
  webpush.setVapidDetails(process.env.VAPID_MAILTO || 'mailto:admin@example.com', process.env.VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY)
  const payload = JSON.stringify({ title: title || 'SportsSpherePro Alert', body: body || 'Update ready', url: url || '/admin.html' })
  let success=0, failed=0
  await Promise.all(subs.map(async sub=>{
    try{ await webpush.sendNotification(sub, payload); success++ }catch(e){ failed++ }
  }))
  return { statusCode:200, body: JSON.stringify({ ok:true, success, failed, total: subs.length }) }
}
