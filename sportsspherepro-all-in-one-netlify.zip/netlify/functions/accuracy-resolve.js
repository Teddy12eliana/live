import { getStore } from '@netlify/blobs'
const STORE='accuracy-store', KEY='accuracy.json'
export async function handler(event){
  if(event.httpMethod!=='POST') return {statusCode:405, body:'Method Not Allowed'}
  const user = event.headers['x-user-email'] || 'admin'
  try{
    const { id, winner, note } = JSON.parse(event.body||'{}')
    if(!id || !winner) return {statusCode:400, body:'id and winner required'}
    const s=getStore(STORE); const txt=await s.get(KEY,{type:'text'}); const list= txt? JSON.parse(txt):[]
    const idx=list.findIndex(r=> r.id===id); if(idx<0) return {statusCode:404, body:'record not found'}
    const rec=list[idx]; if(rec.locked && rec.status==='graded'){ return { statusCode:409, body:'record already locked/graded' } }
    const norm = v => (v||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()
    const ok = norm(rec.predTeam)===norm(winner) || norm(rec.predTeam).includes(norm(winner)) || norm(winner).includes(norm(rec.predTeam))
    rec.manualWinner = winner; rec.resolvedBy = user; rec.resolvedAt = new Date().toISOString()
    if (note) rec.note = String(note).slice(0,500)
    rec.actualWin = !!ok; rec.status = 'graded'; rec.verifiedBy = 'manual-override'; rec.updatedAt = rec.resolvedAt; rec.locked = true
    list[idx] = rec; await s.set(KEY, JSON.stringify(list))
    return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ ok:true, rec }) }
  }catch(e){ return { statusCode:500, body: JSON.stringify({ ok:false, error: e.message }) } }
}
