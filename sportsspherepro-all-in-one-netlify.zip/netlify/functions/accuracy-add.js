import { getStore } from '@netlify/blobs'
export async function handler(event){
  if(event.httpMethod!=='POST') return {statusCode:405, body:'Method Not Allowed'}
  const s=getStore('accuracy-store'); const txt=await s.get('accuracy.json',{type:'text'}); const list= txt? JSON.parse(txt):[]
  const b= JSON.parse(event.body||'{}'); const idx=list.findIndex(r=>r.id===b.id); const now=new Date().toISOString()
  const rec={ id:b.id, sport:b.sport||'ALL', match:b.match||'', predTeam:b.predTeam, predProb: typeof b.predProb==='number'? b.predProb:null, modelCI:b.modelCI||null, commence:b.commence||null, createdAt: (idx>=0? list[idx].createdAt: now), updatedAt: now, actualWin:(idx>=0? list[idx].actualWin:null), gradedAt:(idx>=0? list[idx].gradedAt:null) }
  if (idx>=0) list[idx]=rec; else list.push(rec); await s.set('accuracy.json', JSON.stringify(list))
  return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ ok:true, rec }) }
}
