import { getStore } from '@netlify/blobs'
function compute(rs){
  const graded=rs.filter(r=> typeof r.actualWin==='boolean')
  const wins= graded.filter(r=> r.actualWin).length
  const total= rs.length
  const winRate= graded.length? wins/graded.length:0
  const brier= graded.length? graded.reduce((s,r)=> s+Math.pow((r.predProb??0.5)-(r.actualWin?1:0),2),0)/graded.length: null
  const edges=[0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]; const bins=Array.from({length:edges.length-1},(_,i)=>({lo:edges[i],hi:edges[i+1],count:0,hits:0}))
  for(const r of graded){ const p=Math.max(0,Math.min(0.9999,r.predProb??0.5)); const idx=Math.max(0,Math.min(bins.length-1,Math.floor((p-0.2)/0.1))); bins[idx].count++; if(r.actualWin) bins[idx].hits++ }
  const cal=bins.map(b=>({bin:Math.round(((b.lo+b.hi)/2)*100), rate: b.count? (b.hits/b.count)*100:0, count:b.count}))
  return { total, graded: graded.length, wins, winRate, brier, cal }
}
export async function handler(event){
  const s=getStore('accuracy-store'); const txt=await s.get('accuracy.json',{type:'text'}); const arr= txt? JSON.parse(txt):[]
  const sport=(event.queryStringParameters?.sport||'').toUpperCase(); const filtered= sport? arr.filter(r=>(r.sport||'').toUpperCase()===sport):arr
  const metrics= compute(filtered)
  // Attach current calibration alpha if present
  try{ const ct=await s.get('calibration.json',{type:'text'}); if(ct){ const c=JSON.parse(ct); metrics.alpha=c.alpha } }catch(e){}
  return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ ok:true, ...metrics }) }
}
