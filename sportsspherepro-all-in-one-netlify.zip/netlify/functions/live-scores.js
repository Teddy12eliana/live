export async function handler(){
  const { getStore } = await import('@netlify/blobs')
  const store = getStore('accuracy-store')
  const txt = await store.get('accuracy.json', { type:'text' })
  const arr = txt? JSON.parse(txt): []
  const base = arr.slice(-20).reverse()
  function pick(n){ return base.slice(0,n) }
  const toRow = r => {
    const pred = typeof r.predProb==='number'? r.predProb : 0.55
    const live = Math.max(0.05, Math.min(0.95, pred + (Math.random()-0.5)*0.12))
    return { id: r.id || String(Math.random()), match: r.match || 'TBD vs TBD', league: r.sport || 'ALL', predTeam: r.predTeam || '—', predProb: pred, liveProb: live, delta: (live - pred) }
  }
  const rows = pick(5).map(toRow)
  return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ ok:true, top5: rows }) }
}
