import { getStore } from '@netlify/blobs'
export async function handler(event){
  if (event.httpMethod!=='POST') return { statusCode:405, body:'Method Not Allowed' }
  const s=getStore('accuracy-store')
  const body = JSON.parse(event.body || '{}')
  const txt = await s.get('push-subs.json', { type:'text' })
  const arr = txt? JSON.parse(txt): []
  const key = body?.endpoint
  if (!key) return { statusCode:400, body:'invalid subscription' }
  if (!arr.find(x=> x.endpoint===key)) arr.push(body)
  await s.set('push-subs.json', JSON.stringify(arr))
  return { statusCode:200, body: JSON.stringify({ ok:true, count: arr.length }) }
}
