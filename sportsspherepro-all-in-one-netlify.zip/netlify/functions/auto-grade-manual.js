export { handler } from './auto-grade.js'
