export async function handler(event){
  const id = (event.queryStringParameters?.id)||''
  try{
    const { getStore } = await import('@netlify/blobs')
    const store = getStore('accuracy-store')
    const txt = await store.get('accuracy.json', { type:'text' })
    const arr = txt? JSON.parse(txt): []
    const rec = arr.find(r => r.id===id) || arr.slice(-1)[0]
    const p = rec?.predProb ?? 0.5
    const team = rec?.predTeam || 'the favorite'
    const match = rec?.match || 'this matchup'
    let angle = ''
    if (p >= 0.7) angle = 'strong confidence due to form and matchup edges'
    else if (p >= 0.6) angle = 'rising confidence based on recent momentum'
    else if (p >= 0.55) angle = 'slight edge with room for volatility'
    else angle = 'tight contest; edges are marginal'
    const text = `Model favors ${team} in ${match} with ${Math.round(p*100)}% confidence — ${angle}.`
    return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ ok:true, id, text }) }
  }catch(e){
    return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ ok:true, id, text:'Model narrative pending.' }) }
  }
}
