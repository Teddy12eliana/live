import { getStore } from '@netlify/blobs'
export async function handler(event){
  if(event.httpMethod!=='POST') return {statusCode:405, body:'Method Not Allowed'}
  const {id, actualWin}= JSON.parse(event.body||'{}')
  if(!id || typeof actualWin!=='boolean') return {statusCode:400, body:'id and boolean actualWin required'}
  const s=getStore('accuracy-store'); const txt=await s.get('accuracy.json',{type:'text'}); const list= txt? JSON.parse(txt):[]
  const idx=list.findIndex(r=> r.id===id); if(idx<0) return {statusCode:404, body:'record not found'}
  list[idx].actualWin=actualWin; list[idx].gradedAt=new Date().toISOString(); list[idx].updatedAt=list[idx].gradedAt
  await s.set('accuracy.json', JSON.stringify(list))
  return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ ok:true, rec:list[idx] }) }
}
