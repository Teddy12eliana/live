export async function handler(event){
  const tier = (event.queryStringParameters?.tier || 'starter').toLowerCase()
  const allowed = ['starter','pro','analyst'].includes(tier) ? tier : 'starter'
  return { statusCode:200, headers:{'content-type':'application/json'}, body: JSON.stringify({ ok:true, tier: allowed, access: allowed==='starter'?'Top 5 only':'All games + history' }) }
}
