import { getStore } from '@netlify/blobs'
const fetch = (await import('node-fetch')).default

export const config = { schedule: "*/15 * * * *" }

const STORE='accuracy-store', KEY='accuracy.json', STATUS='accuracy-status.json', CALIB='calibration.json'
const SPORT_MAP={ NBA:'basketball_nba', NFL:'americanfootball_nfl', MLB:'baseball_mlb', NHL:'icehockey_nhl', EPL:'soccer_epl', LA_LIGA:'soccer_spain_la_liga', SERIE_A:'soccer_italy_serie_a', BUNDESLIGA:'soccer_germany_bundesliga', MLS:'soccer_usa_mls' }
const SDB_LEAGUE={ EPL:'4328', LA_LIGA:'4335', SERIE_A:'4332', BUNDESLIGA:'4331', MLS:'4346' }
const norm=s=>(s||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()
function winnerFromOddsGame(g){ if(!g||!g.completed||!Array.isArray(g.scores)) return null; let best=null, top=-1e9; for(const s of g.scores){ const sc=Number(s.score); if(!isNaN(sc)&&sc>top){ top=sc; best=s.name } } return best }
function winnerFromSdbEvent(ev){ if(!ev) return null; const hs=Number(ev.intHomeScore??ev.home_score), as=Number(ev.intAwayScore??ev.away_score); if(isNaN(hs)||isNaN(as)) return null; if(hs>as) return ev.strHomeTeam??ev.home_team; if(as>hs) return ev.strAwayTeam??ev.away_team; return null }

function computeMetrics(rs){
  const graded=rs.filter(r=> typeof r.actualWin==='boolean')
  const wins= graded.filter(r=> r.actualWin).length
  const total= rs.length
  const winRate= graded.length? wins/graded.length:0
  const brier= graded.length? graded.reduce((s,r)=> s+Math.pow((r.predProb??0.5)-(r.actualWin?1:0),2),0)/graded.length: null
  return { total, graded: graded.length, wins, winRate, brier }
}

export async function handler(){
  const store=getStore(STORE)
  const txt=await store.get(KEY,{type:'text'})
  const list= txt? JSON.parse(txt):[]

  const ungraded=list.filter(r=> typeof r.actualWin!=='boolean')
  const start=Date.now(); let graded=0, checked=0, pending=0, conflicts=0, errors=0
  const bySport={}; for(const r of ungraded){ const s=(r.sport||'EPL').toUpperCase(); (bySport[s]??=[]).push(r) }

  for(const sportKey of Object.keys(bySport)){
    let oddsIndex=new Map()
    if (process.env.ODDS_API_KEY && SPORT_MAP[sportKey]){
      try{
        const u=`https://api.the-odds-api.com/v4/sports/${SPORT_MAP[sportKey]}/scores/?daysFrom=5&apiKey=${process.env.ODDS_API_KEY}`
        const resp=await fetch(u); const arr=await resp.json()
        oddsIndex=new Map((arr||[]).map(g=>[g.id,g]))
      }catch(e){ errors++ }
    }

    let sdbEvents=[]
    if (SDB_LEAGUE[sportKey]){
      try{
        const keyPart=process.env.THESPORTSDB_KEY? `/1/json/${process.env.THESPORTSDB_KEY}`:'/1'
        const url=`https://www.thesportsdb.com/api/v1/json${keyPart}/eventspastleague.php?id=${SDB_LEAGUE[sportKey]}`
        const r=await fetch(url); const d=await r.json()
        sdbEvents=d.events||[]
      }catch(e){ errors++ }
    }

    for(const rec of bySport[sportKey]){
      checked++
      const game= rec.id? oddsIndex.get(rec.id): null
      const oddsWinner= winnerFromOddsGame(game)
      let sdbWinner=null
      if(sdbEvents.length && rec.match){
        const [away, home]=(rec.match||'').split(' vs ').map(x=>x&&x.trim())
        const an=norm(away), hn=norm(home)
        const ev=sdbEvents.find(e=>{ const evA=norm(e.strAwayTeam), evH=norm(e.strHomeTeam); return ((evA.includes(an)||an.includes(evA)) && (evH.includes(hn)||hn.includes(evH))) })
        sdbWinner=winnerFromSdbEvent(ev)
      }
      if(!oddsWinner && !sdbWinner){ pending++; continue }
      if(oddsWinner && sdbWinner && norm(oddsWinner)!==norm(sdbWinner)){
        rec.status='conflict'; rec.sources={ oddsWinner, sdbWinner }; rec.updatedAt=new Date().toISOString(); conflicts++; continue
      }
      const decided= oddsWinner || sdbWinner
      const ok = norm(rec.predTeam)===norm(decided) || norm(rec.predTeam).includes(norm(decided)) || norm(decided).includes(norm(rec.predTeam))
      rec.actualWin=!!ok
      rec.gradedAt=new Date().toISOString()
      rec.updatedAt=rec.gradedAt
      rec.status='graded'
      rec.source= oddsWinner? 'auto-odds':'auto-sdb'
      graded++
    }
  }

  // Save list + status
  await store.set(KEY, JSON.stringify(list))
  const mets = computeMetrics(list)
  const status = { ok:true, graded, checked, pending, conflicts, errors, ts:new Date().toISOString(), ms: Date.now()-start, source:'auto', ...mets }
  await store.set(STATUS, JSON.stringify(status))

  // --- Calibration update (simple alpha factor based on Brier) ---
  let alpha = 1.0
  try{
    const ct = await store.get(CALIB, { type:'text' })
    const prev = ct? JSON.parse(ct): { alpha: 1.0, history: [] }
    alpha = prev.alpha
    const target = 0.20 // ideal Brier (rough, depends on sport mix)
    if (mets.brier!=null){
      const diff = target - mets.brier
      alpha = Math.max(0.90, Math.min(1.10, alpha + diff * 0.10)) // gentle nudges
    }
    const history = (prev.history||[]).concat([{ ts: Date.now(), brier: mets.brier, alpha }]).slice(-200)
    await store.set(CALIB, JSON.stringify({ alpha, history }))
  }catch(e){}

  // --- Optional webhook alert if thresholds crossed ---
  try{
    const url = process.env.WEBHOOK_URL
    if (url && (conflicts>0 || (mets.winRate && mets.winRate<0.55))){
      await fetch(url, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ text:`Integrity Engine: graded=${graded}, conflicts=${conflicts}, winRate=${(mets.winRate||0).toFixed(2)}, brier=${mets.brier?.toFixed(3)}` }) })
    }
  }catch(e){}

  return { statusCode:200, body:`graded=${graded} checked=${checked} pending=${pending} conflicts=${conflicts} brier=${mets.brier}` }
}
