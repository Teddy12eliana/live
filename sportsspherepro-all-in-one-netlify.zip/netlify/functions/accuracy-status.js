import { getStore } from '@netlify/blobs'
const STORE='accuracy-store', KEY='accuracy-status.json'
export async function handler(){ const s=getStore(STORE); const txt=await s.get(KEY,{type:'text'}); return { statusCode:200, headers:{'content-type':'application/json'}, body: txt || JSON.stringify({ ok:false, note:'No runs yet' }) } }
