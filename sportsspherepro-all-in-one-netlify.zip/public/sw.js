self.addEventListener('install', event => { self.skipWaiting() })
self.addEventListener('activate', event => { self.clients.claim() })
self.addEventListener('push', event => {
  let data = {}
  try { data = event.data ? event.data.json() : {} } catch(e){}
  const title = data.title || 'SportsSpherePro Alert'
  const body  = data.body || 'Update from Integrity Engine'
  const icon  = data.icon || '/favicon.ico'
  const badge = data.badge || '/favicon.ico'
  event.waitUntil(self.registration.showNotification(title, { body, icon, badge, data }))
})
self.addEventListener('notificationclick', event => {
  event.notification.close()
  const url = (event.notification.data && event.notification.data.url) || '/admin.html'
  event.waitUntil(clients.matchAll({type:'window'}).then(list => {
    for (const client of list){ if (client.url===url && 'focus' in client) return client.focus() }
    if (clients.openWindow) return clients.openWindow(url)
  }))
})
