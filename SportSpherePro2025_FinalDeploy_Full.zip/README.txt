Upload ZIP to Netlify. Set publish=public and functions=netlify/functions.
